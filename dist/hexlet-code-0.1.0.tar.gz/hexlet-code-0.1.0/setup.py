# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Hexlet tests and linter status:\n\n\n[![Actions Status](https://github.com/gravanofranchezd/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/gravanofranchezd/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/c319671fcf845feb0d77/maintainability)](https://codeclimate.com/github/gravanofranchezd/python-project-49/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/c319671fcf845feb0d77/test_coverage)](https://codeclimate.com/github/gravanofranchezd/python-project-49/test_coverage)\n\n\n## Install:\n\n\n```\ngit clone https://github.com/gravanofranchezd/python-project-49\ncd python-project-49\nmake package-install\n```\n\n## Usage:\n\n\n* Even number: `brain-even`\n* Calculate the expression: `brain-calc`\n* Greatest common divisor: `brain-gcd`\n* Guess missing number: `brain-progression`\n* Prime number: `brain-prime`\n\n\n## Asciinema:\n\n\n<a href="https://asciinema.org/a/yygJBZfpkg4ZfCJuU3Fn7pYkf" target="_blank"><img src="https://asciinema.org/a/yygJBZfpkg4ZfCJuU3Fn7pYkf.svg" /></a>\n<a href="https://asciinema.org/a/4hsksFN2N7zayMe0YOpLk8Ver" target="_blank"><img src="https://asciinema.org/a/4hsksFN2N7zayMe0YOpLk8Ver.svg" /></a>\n<a href="https://asciinema.org/a/4au8fgCwQfR97X2ky13ws8VCJ" target="_blank"><img src="https://asciinema.org/a/4au8fgCwQfR97X2ky13ws8VCJ.svg" /></a>\n<a href="https://asciinema.org/a/TGGx79yXMzhSZ4KgrHl1YFrtx" target="_blank"><img src="https://asciinema.org/a/TGGx79yXMzhSZ4KgrHl1YFrtx.svg" /></a>\n<a href="https://asciinema.org/a/YgYpK8MVK3N0CD7scLlaUWAqE" target="_blank"><img src="https://asciinema.org/a/YgYpK8MVK3N0CD7scLlaUWAqE.svg" /></a>\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
