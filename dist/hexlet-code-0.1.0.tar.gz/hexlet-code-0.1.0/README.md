### Hexlet tests and linter status:
[![Actions Status](https://github.com/gravanofranchezd/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/gravanofranchezd/python-project-49/actions)
https://asciinema.org/connect/c6133a0f-1517-41a9-ba1c-f2c27ae0e2a9
https://asciinema.org/a/RVLY4vZXu5nw1awjPedeOFQjI